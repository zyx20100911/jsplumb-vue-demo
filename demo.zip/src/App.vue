<template>
  <div id="app">
<!--    <div>项目地址：<a href="https://github.com/Code-RoadFly/jsplumb-vue-wordFlow" target="_blank">https://github.com/Code-RoadFly/jsplumb-vue-wordFlow</a></div>-->
    <router-view/>
  </div>
</template>

<style lang="less">
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  width: 100%;
  height: 100%;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}
</style>
